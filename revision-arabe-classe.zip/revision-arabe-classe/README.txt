Mode classe

Ouvrez index.html pour tester localement.
Pour publier rapidement, importez le dossier sur un hébergeur de sites statiques.
IMPORTANT: les données LocalStorage restent sur le même navigateur/appareil. Pour partager des résultats entre appareils, il faudra connecter une base de données (Supabase/Firebase).
